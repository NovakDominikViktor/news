import React, { useState, useEffect } from 'react';
import NavBar from './NavBar';
import Home from './Home';
import NewsSinglePage from './NewsSinglePage'; // Import your NewsSinglePage component
import 'bootstrap/dist/css/bootstrap.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

const App = () => {
  const [language, setLanguage] = useState('en');
  const [news, setNews] = useState([]);

  const changeLanguage = (lng) => {
    setLanguage(lng);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`https://localhost:7010/api/News?language=${language}`, {
          method: 'GET',
        });
        const data = await response.json();
        setNews(data);
      } catch (error) {
        console.error('Error fetching news:', error);
      }
    };

    fetchData();
  }, [language]);

  return (
    <Router>
      <div>
        <NavBar changeLanguage={changeLanguage} />
        <Routes>
          <Route
            path="/"
            element={<Home news={news} language={language} changeLanguage={changeLanguage} />}
          />
          <Route
            path="/news"
            element={<Home news={news} language={language} changeLanguage={changeLanguage} />}
          />
          <Route
            path="/news/:id"
            element={<NewsSinglePage language={language} changeLanguage={changeLanguage} />}
          />
        </Routes>
      </div>
    </Router>
  );
};

export default App;