import React from 'react';
import NewsCard from './NewsCard';
import { Link } from 'react-router-dom';

const NewsList = ({ news, language }) => {
  return (
    <div className="row">
      {news.map((item) => (
        <div className="col-md-4 mb-4" key={item.id}>
          <Link to={`/news/${item.newsId}`}>
            <NewsCard
              id={item.newsId}
              title={item.newsTitle}
              content={language === 'en' ? item.newsFullEn : item.newsFullHu}
              language={language}
              newsBrief={item.newsBrief}
              newsCategory={item.newsCategory}
              newsFullEn={item.newsFullEn}
              newsFullHu={item.newsFullHu}
              newsPict={item.newsPict}
              newsPict2={item.newsPict2}
              newsTitle={item.newsTitle}
            />
          </Link>
        </div>
      ))}
    </div>
  );
};

export default NewsList;
