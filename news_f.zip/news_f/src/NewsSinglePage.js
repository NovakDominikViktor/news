// NewsSinglePage.js
import React, { useState, useEffect } from 'react';
import { useParams, NavLink } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';

const NewsSinglePage = ({ language, changeLanguage }) => {
  const { id } = useParams();
  const [news, setNews] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSingleNews = async () => {
      try {
        const response = await fetch(`https://localhost:7010/api/News/${id}?language=${language}`);
        const data = await response.json();
        setNews(data);
      } catch (error) {
        console.error('Error fetching single news:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSingleNews();
  }, [id, language]);

  // Splitting the newsTitle
  const displayTitle = language === 'en' ? news.newsTitle?.split(' - ')[1] : news.newsTitle?.split(' - ')[0];

  return (
    <div className="container mt-4">
      {loading ? (
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : (
        <div className="card">
          <div className="card-body">
            <h5 className="card-title">{displayTitle}</h5>
            <div className="col-md-6">
              {news.newsPict && (
                <img
                  src={`data:image/jpeg;base64, ${news.newsPict}`}
                  style={{ width: '20%', height: 'auto' }} // Assuming newsPict is a base64 string
                  className="card-img-top img-fluid"
                  alt={`News Image for ${news.newsTitle}`}
                />
              )}
            </div>
            <p className="card-subtitle mb-2 text-muted">{news.newsBrief}</p>
            <p className="card-text">{news.newsCategory}</p>
            <p className="card-text">{news.language}</p>
            <p className="card-text">{language === 'en' ? news.newsFullEn : news.newsFullHu}</p>
            <div className="row justify-content-end">
              <div className="col-md-6">
                {news.newsPict2 && (
                  <img
                    src={`data:image/jpeg;base64, ${news.newsPict2}`}
                    style={{ width: '20%', height: 'auto' }} // Assuming newsPict2 is a base64 string
                    className="card-img-top img-fluid"
                    alt={`Second News Image for ${news.newsTitle}`}
                  />
                )}
              </div>
            </div>
            <br/>
            <div className="row justify-content-center align-items-center">
              <NavLink to="/" className="btn btn-primary">
                Back to News
              </NavLink>
            </div>
           
          </div>
        </div>
      )}
    </div>
  );
};

export default NewsSinglePage;
