// Home.js
import React from 'react';
import NewsList from './NewsList';

const Home = ({ language }) => {
  return (
    <div>
      <h2>Welcome to the News Page!</h2>
      <NewsList language={language} />
    </div>
  );
};

export default Home;
