import React from 'react';

const LanguageSelector = ({ onChangeLanguage }) => {
  return (
    <select onChange={(e) => onChangeLanguage(e.target.value)}>
      <option value="en">English</option>
      <option value="hu">Magyar</option>
    </select>
  );
};

export default LanguageSelector;
