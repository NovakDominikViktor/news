// NewsCard.js
import React from 'react';

const NewsCard = ({ language, newsFullEn, newsFullHu, newsTitle }) => {
  const displayTitle = language === 'en' ? newsTitle.split(' - ')[1] : newsTitle.split(' - ')[0];
  const displayContent = language === 'en' ? newsFullEn : newsFullHu;

  return (
    <div className="card">
      
      <div className="card-body">
        <h5 className="card-title">{displayTitle}</h5>
        <p className="card-text">{displayContent}</p>
      </div>
    </div>
  );
};

export default NewsCard;
