import React, { useState, useEffect } from 'react';
import NavBar from './NavBar';
import PageTitle from './PageTitle';
import NewsList from './NewsList';
import 'bootstrap/dist/css/bootstrap.css'

const App = () => {
  const [language, setLanguage] = useState('en');
  const [news, setNews] = useState([]);

  const changeLanguage = (lng) => {
    setLanguage(lng);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`https://localhost:7010/api/News?language=${language}`, {
          method: 'GET',
        });
        const data = await response.json();
        console.log('Data:', data); // Új sor
        setNews(data);
      } catch (error) {
        console.error('Error fetching news:', error);
      }
    };

    fetchData();
  }, [language]);

  return (
    <div>
      <NavBar changeLanguage={changeLanguage} />
      <PageTitle title="Latest News" />
      <NewsList news={news} language={language} />
    </div>
  );
};

export default App;
