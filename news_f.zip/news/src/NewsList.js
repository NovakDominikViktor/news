// NewsList.js
import React from 'react';
import NewsCard from './NewsCard';

const NewsList = ({ news, language }) => {
  return (
    <div className="row">
      {news.map((item) => (
        <div className="col-md-4 mb-4" key={item.id}>
          <NewsCard
            title={item.newsTitle}
            content={language === 'en' ? item.newsFullEn : item.newsFullHu}
            language={language}
            id={item.id}
            newsBrief={item.newsBrief}
            newsCategory={item.newsCategory}
            newsFullEn={item.newsFullEn}
            newsFullHu={item.newsFullHu}
            newsPict={item.newsPict}
            newsTitle={item.newsTitle}
          />
        </div>
      ))}
    </div>
  );
};

export default NewsList;
