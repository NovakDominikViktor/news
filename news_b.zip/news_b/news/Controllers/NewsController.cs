﻿// Controllers/NewsController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using news.Models;

[Route("api/[controller]")]
[ApiController]
public class NewsController : ControllerBase
{
    private readonly NewsContext _context;

    public NewsController(NewsContext context)
    {
        _context = context;
    }

    // GET: api/News
    [HttpGet]
    public async Task<ActionResult<IEnumerable<News>>> GetNews([FromQuery] string language = "en")
    {
        var newsList = await _context.News
            .Select(news => new News
            {
                NewsId = news.NewsId,
                NewsTitle = news.NewsTitle,
                NewsBrief = news.NewsBrief,
                NewsCategory = news.NewsCategory,
                NewsFullHu = news.NewsFullHu,
                NewsFullEn = news.NewsFullEn,
                NewsPict = news.NewsPict, 
                NewsPict2 = news.NewsPict2 
            })
            .ToListAsync();

        // Szűrje az eredményeket a kiválasztott nyelv alapján
        if (language.ToLower() == "hu")
        {
            newsList.ForEach(news => news.NewsFullEn = null);
        }
        else if (language.ToLower() == "en")
        {
            newsList.ForEach(news => news.NewsFullHu = null);
        }

        return Ok(newsList);
    }


    [HttpGet("{id}")]
    public async Task<ActionResult<News>> GetNewsById(int id)
    {
        var news = await _context.News.FindAsync(id);

        if (news == null)
        {
            return NotFound();
        }
        return Ok(news);
    }
}