﻿using System;
using System.Collections.Generic;

namespace news.Models;

public partial class News
{
    public int NewsId { get; set; }

    public string NewsTitle { get; set; } = null!;

    public string NewsBrief { get; set; } = null!;

    public string NewsCategory { get; set; } = null!;

    public string NewsFullHu { get; set; } = null!;

    public string NewsFullEn { get; set; } = null!;

    public byte[]? NewsPict { get; set; }

    public byte[]? NewsPict2 { get; set; }
}
